// empty lambda for placeholder purposes

exports.handler = function( event, context ) {
  console.log('empty lambda handler');
}
